/**
 * Created by pitra on 2.5.2017.
 */

package sibenice;
        import java.util.Scanner;

public class sibenice {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in, "UTF-8");
        String[] slovnik = {"server", "java", "databaze", "programovani"};

        int spatne = 0;
        int dobre = 0;

        //výběr slova z databáze
        String slovo = slovnik[(int)(Math.random()*slovnik.length)];

        char[] postup = new char[slovo.length()];

        //vytvoříme potřebný počet '-' jako nahrazeni znaku
        for(int i=0;i!=slovo.length();i++)
            postup[i] ='-';

        //řídící cyklus
        while (spatne!=7&&dobre!=slovo.length())
        {
            //výpis postupu na obrazovku
            for(char c:postup)
                System.out.printf("%c",c);
            System.out.printf("\nZadej písmenko: ");
            String volba = sc.nextLine();
            //ošetřetí vstupu proti velkým písmenům
            volba = volba.toLowerCase();
            //pokud zadané písmeno není obsaženo ve slově, přičteme trestný bod
            if(slovo.contains(volba))
            {
                /*ověření, zda zadané písmeno je obsaženo ve slově,plus
                opatření pro opakovanému zadání stejného písmene*/
                for(int i=0;i!=slovo.length();i++)
                    if(volba.equals(Character.toString(slovo.charAt(i)))&&
                            postup[i]!=slovo.charAt(i))
                    {
                        postup[i]=slovo.charAt(i);
                        dobre+=1;
                    }
            }
            else
                spatne+=1;
            //vykreslování šibenice na základě špatných pokusů
            switch (spatne)
            {
                case 7:
                    System.out.println("      ___________\n"
                            + "     ││        I\n"
                            + "     ││       ( )\n"
                            + "     ││        │\n"
                            + "     ││       /│\\\n"
                            + "     ││        │\n"
                            + "     ││       / \\\n"
                            + "    .---.\n"
                            + "   /     \\");
                    System.out.println("Smula!\n"
                            + "Spravne to je: " + slovo);
                    break;
                case 6:
                    System.out.println("      ___________\n"
                            + "     ││        I\n"
                            + "     ││       ( )\n"
                            + "     ││        │\n"
                            + "     ││        │\n"
                            + "     ││        │\n"
                            + "     ││       / \\\n"
                            + "    .---.\n"
                            + "   /     \\");
                    break;
                case 5:
                    System.out.println("      ___________\n"
                            + "     ││        I\n"
                            + "     ││       ( )\n"
                            + "     ││        │\n"
                            + "     ││        │\n"
                            + "     ││        │\n"
                            + "     ││\n"
                            + "    .---.\n"
                            + "   /     \\");
                    break;
                case 4:
                    System.out.println("      ___________\n"
                            + "     ││        I\n"
                            + "     ││       ( )\n"
                            + "     ││\n"
                            + "     ││\n"
                            + "     ││\n"
                            + "     ││\n"
                            + "    .---.\n"
                            + "   /     \\");
                    break;
                case 3:
                    System.out.println("      ___________\n"
                            + "     ││        I\n"
                            + "     ││\n"
                            + "     ││\n"
                            + "     ││\n"
                            + "     ││\n"
                            + "     ││\n"
                            + "    .---.\n"
                            + "   /     \\");
                    break;
                case 2:
                    System.out.println("\n     ││\n"
                            + "     ││\n"
                            + "     ││\n"
                            + "     ││\n"
                            + "     ││\n"
                            + "     ││\n"
                            + "    .---.\n"
                            + "   /     \\");
                    break;
                case 1:
                    System.out.println("\n\n\n\n\n\n\n    .---.\n"
                            + "   /     \\");
                    break;
                default :
            }
        }
        if(spatne!=7)
            System.out.println("Neumrel jsi!!");
    }
}